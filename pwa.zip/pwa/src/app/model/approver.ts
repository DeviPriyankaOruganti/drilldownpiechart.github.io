export class Approver{
    ApproverName:string;
    count:number;
}