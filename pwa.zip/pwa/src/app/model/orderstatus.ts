export class OrderStatus {
      ReqNum:string;
      ReqName:string;
      Approve_Begin_Date_UTC:string;
      Days:string;
      ApprovalStatus:string;
      ApproverName:string;
      BORGNAME:string
} 