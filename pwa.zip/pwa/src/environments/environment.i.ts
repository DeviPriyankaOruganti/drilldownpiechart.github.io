export interface Environment {
    readonly api: string;
    readonly production: boolean;
  }