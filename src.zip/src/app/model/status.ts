import { Approver } from './approver';

export class Status {
    ApprovalStatus : string;
    count : number;
    approverNames : Approver[];
} 