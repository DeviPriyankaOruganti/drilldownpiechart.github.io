import { Environment } from './environment.i';

export const environment: Environment = {
  production: true,
  api: 'https://bp.ocp.got.volvo.net/bp', 
};
